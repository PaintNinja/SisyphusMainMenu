The website now uses WebM if availible with the original MP4 as a fallback.

Both videos are still 20 seconds and the same quality, but the file sizes are very different.

MP4:  7.34MB
WebM: 1.14MB

Because of the lower file size WebM offers, if compatible and WebM is in use,
you'll notice a significant performance improvement - especially on slow internet
connections.